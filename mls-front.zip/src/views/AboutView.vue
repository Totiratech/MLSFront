<template>
  <div class="about">
    <div class="about-slider">
      <section class="panel first-panel about-header">
        <h1 class="hero-h">ABOUT<br />CRIMSON<br />ROSE</h1>
        <div class="t-line"></div>
      </section>

      <section class="panel">
        <div class="row">
          <div class="col-4 about-butterfly-section">
            <p>
              Crimson Rose has gained a reputation for completing various
              significant projects, reinforcing creativity, investing in growing
              technologies, and producing a meaningful impact for their
              customers, personnel and local community.
            </p>
            <img
              src="@/assets/images/about/Group 1171275338.png"
              alt="crimson butterfly logo"
            />
          </div>
          <div class="col-6 meet">
            <div class="meet-img">
              <img src="@/assets/images/about/about.png" alt="" />
            </div>
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="container">
          <div class="row project-management">
            <div class="section-txt col-5">
              <h2>Project Management and Construction Services</h2>
              <p>
                Crimson Rose is a Canadian-based project management and
                construction services company and is a prominent building
                contractor in the luxury custom-home sector.
              </p>
              <p>
                The company has gained a reputation for completing various
                significant projects, reinforcing creativity, investing in
                growing technologies, and producing a meaningful impact for its
                customers, personnel and the local community.
              </p>
              <p>
                With a team of highly skilled employees and management whose
                focus is laser-sharp on their work, we provide clients with
                convenience and confidence throughout the life of the project
                and for many years to follow.
              </p>
            </div>
            <div class="project-imgs col-6">
              <img src="@/assets/images/about/stairs.jpg" alt="" />
              <img src="@/assets/images/about/project-bed.png" alt="" />
            </div>
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="container">
          <div class="row design">
            <div class="section-txt col-5">
              <h2>Our Design Philosophy</h2>
              <p>
                Our design philosophy is centered around three key pillars:
                Communication, Function and Aesthetics. Through open
                communication, the custom home design process can be seamless
                and extremely enjoyable.
              </p>
              <p>
                Our goal is to bring our clients’ vision to life through an
                innovative design that both match their lifestyle and budget
                requirements. Our clients also benefit from a full suite of
                expertise that includes architectural design, construction and
                in-house realty for investment opportunities. Function is our
                highest priority. We listen carefully to our clients’ daily
                needs and aesthetic preferences to design a space that suits
                them now and in the years to come.
              </p>
              <p>
                Equally important to a seamless design process is the ability to
                deliver on time and within budget. Meeting the budget is a
                value-driven exercise that includes choosing the right material
                for its intended purpose, reducing unusable space or achieving a
                high mechanical efficiency to reduce future operating costs.
              </p>
              <p>
                We are committed to walking our clients through each step of the
                design process while ensuring a clear focus is maintained on
                each of the three facets of our design philosophy.
              </p>
            </div>
            <div class="col-4 offset-2">
              <img src="@/assets/images/about/design.png" alt="" />
            </div>
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="container">
          <div class="row innovation">
            <div class="section-txt col-5">
              <h2>Innovation For Proper Development</h2>
              <p>
                Our goal is to be the best in the business and be among the most
                highly-respected building contractors in Canada.
              </p>
              <p>
                At Crimson Rose Living, we understand the fact that
                exceptionality plays a key role in making us stand out as the
                best among the rest. It’s a part of who we are and how we do our
                business. Our passion for this business is so strong that it
                guides our actions in everything that we do..
              </p>
              <p>
                We are here to develop long-term relationships with many clients
                and cultivate the finest reputation for our company. While our
                values are distinctive, we constantly embrace new technologies
                and positive ways to solve problems. We are Crimson Rose Living,
                and our mission is to raise the bar for quality.
              </p>
            </div>
            <div class="col-6 offset-1 innovation-grid">
              <img src="@/assets/images/about/innovation.png" alt="" />
            </div>
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="container">
          <div class="row resources">
            <div class="section-txt col-5 offset-1">
              <h2>Resources with Capabilities to Deliver</h2>
              <p>
                At Crimson Rose Living, we are fully aware that we are providing
                complex and challenging services that are high in demand, but
                for you the customer, we make certain to break down the process
                to ensure that you understand what we are doing on your project.
                We also understand the difficulties that come with building in
                some communities of Canada and it is part of our mission to
                guarantee that the construction experience for our clients is
                enjoyable, satisfactory and stress-free. We provide a variety of
                Building and Construction services. By incorporating all of
                these fields under one roof, we can secure efficiency in
                providing the highest quality of construction service and
                exclusively guarantee the superiority of the project.
              </p>
              <p>
                For new clients who want to hire us, we offer architectural
                services. We do our best to make sure that your ideas are
                transformed into several building plans that you’ll appreciate.
                We also engage our clients throughout the project through our
                state of the art management software that directly communicates
                with our teams involved in the project. Use your computer,
                tablet or mobile phone to fully engage in the project while also
                having fun.
              </p>
            </div>
            <div class="col-5 why why-1 offset-1">
              <p class="l-txt">WHY CRIMSON ROSE</p>
              <div class="why-img">
                <img src="@/assets/images/about/why.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="container">
          <div class="row">
            <div class="two-sec col-9 offset-1">
              <div class="why-flex">
                <div>
                  <h2>Experience</h2>
                  <p>
                    Our building experience in Canada gives you confidence in
                    our overall performance and an ambiance that is rare in
                    North America which is a key element in ensuring that your
                    design goal is fully reached.
                  </p>
                </div>
                <div>
                  <h2>Top Quality<br />Construction</h2>
                  <p>
                    We deliver the highest standards in the construction
                    industry. We use the latest innovations and our exposure to
                    Western standards to assure that the completed product is of
                    the premier possible value.
                  </p>
                </div>
              </div>
              <div class="why-flex-2">
                <h2>Integrity</h2>
                <p>
                  We believe in business built on trust and integrity. This
                  belief is adopted from an understanding of the importance of
                  honesty in our personal relationship with others as the key to
                  living a happy life. We, therefore, choose to follow the same
                  path in our business to help us grow from strength to
                  strength. As a result, we employ people who value the
                  importance of building trust in a business and also practice
                  it themselves.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="container">
          <div class="row">
            <div class="col-5 why why-1 offset-1">
              <div class="why-img">
                <img src="@/assets/images/about/why2.png" alt="" />
              </div>
              <p class="l-txt">WHY CRIMSON ROSE</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<script>
// import "@/assets/gsap/SplitText.min.js";

/* fake horizontal  */

// let aboutSections = gsap.utils.toArray("about-slider .panel");
// console.log(aboutSections);
// let panellength = document.querySelector(".about-slider").offsetWidth;
// gsap.to(aboutSections, {
//   xPercent: -100 * (aboutSections.length - 1),
//   ease: "none",
//   scrollTrigger: {
//     trigger: ".about-slider",
//     pin: true,
//     scrub: 1,
//     snap: 1 / (aboutSections.length - 1),
//     end: () => "+=" + panellength,
//   },
// });
// /* animate text */
// const childSplit = new SplitText(".hero-h", {
//   type: "lines",
//   linesClass: "split-child",
// });
// const parentSplit = new SplitText(".hero-h", {
//   // type: "lines",
//   linesClass: "split-parent",
// });

// const pChildSplit = new SplitText(".hero-p", {
//   type: "lines",
//   linesClass: "split-child",
// });
// const pParentSplit = new SplitText(".hero-p", {
//   // type: "lines",
//   linesClass: "split-parent",
// });

// gsap
//   .timeline()
//   .from(childSplit.lines, {
//     duration: 1.5,
//     yPercent: 100,
//     ease: "power4",
//     //onComplete:allDone
//   })
//   .from(
//     pChildSplit.lines,
//     {
//       duration: 1,
//       yPercent: 100,
//       ease: "power4",
//       stagger: 0.2,
//       //onComplete:allDone
//     },
//     "-=0.5"
//   );

// gsap.from(".t-line", {
//   scaleX: 0,
//   transformOrigin: "left",
//   duration: 2,
//   delay: 1,
// });
</script>

<style scoped>
body {
  overflow-x: hidden;
}

html,
body {
  margin: 0;
  height: 100%;
  -webkit-overflow-scrolling: touch;
  overflow-scrolling: touch;
  scroll-behavior: smooth;
}

.about-slider {
  width: 700%;
  max-height: 100vh;
  display: flex;
  flex-wrap: nowrap;
}

.about-header {
  position: relative;
}

.about-header h1 {
  font-family: "Literata";
  font-style: normal;
  font-weight: 400;
  font-size: 10rem;
  line-height: 10rem;
  text-transform: capitalize;
  color: #ffffff;
}

.about-header .t-line {
  width: 70vw;
  height: 2px;
  background-color: #ffffff;
  position: absolute;
  top: 35.5%;
  right: -38vw;
}

.about-butterfly-section {
  position: relative;
}

.about-butterfly-section img {
  position: absolute;
  right: -112px;
  top: 189px;
}

.project-management {
  justify-content: space-between;
}

.about-slider .panel .row .section-txt {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 24px;
}

.about-slider .panel .row .section-txt h2 {
  font-family: "Lato";
  font-style: normal;
  font-weight: 700;
  font-size: 40px;
  line-height: 48px;
  text-transform: capitalize;
}

.about-slider .panel .row .section-txt p {
  font-family: "Lato";
  font-style: normal;
  font-weight: 500;
  font-size: 16px;
  line-height: 19px;
  color: #c8c8c8;
}

.project-management .project-imgs {
  width: 50%;
  display: flex;
  flex-direction: column;
  /* grid-template-areas: 
    '. bed bed'
    'st bed bed'
    'st st .'
    ; */
}

.project-management .project-imgs img:first-of-type {
  width: 375px;
  order: 2;
  margin-top: -200px;
}

.project-management .project-imgs img:last-of-type {
  width: 375px;
  margin-left: 150px;
  order: 1;
  z-index: 2;
}

.why {
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
}

.why-img {
  display: flex;
  align-items: flex-end;
}

.why .l-txt {
  font-size: 2.9rem;
  color: #c8c8c8;
  font-weight: 700;
  z-index: 2;
}

.why-flex {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  height: 50vh;
}

/* .why-flex p{
    width: 300px;
} */

.two-sec {
  display: flex;
  justify-content: space-between;
  flex-direction: row;
  align-items: center;
  gap: 30px;
}

.two-sec {
  text-align: center;
}

.why-flex div,
.two-sec div:last-of-type {
  width: 400px;
}
</style>
