<template>
  <div class="error light_grey_bg">
    <div class="container py-5">
      <div class="row">
        <div class="col-9 mx-auto">
          <div
            class="white_box p-5 d-flex flex-column justify-content-center align-items-center"
          >
            <img
              src="@/assets/images/error.png"
              alt=".."
              class="img_fluid error_page"
            />
            <h2 class="black_font capitalize mt-3">page not found !</h2>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<style scoped>
.error_page {
  width: 600px;
}
</style>
